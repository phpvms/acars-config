import { AircraftConfigSimType, AircraftFeature, FeatureType } from '../defs'
import { AircraftConfig } from '../interface/aircraft'
export default class Felis742 extends AircraftConfig {
  meta = {
    id: 'felis_742',
    name: 'Felis 742',
    sim: AircraftConfigSimType.XPlane,
    enabled: true,
    priority: 2,
  }
  features = {
    [AircraftFeature.BeaconLights]: false,
    [AircraftFeature.LandingLights]: {
      'B742/ext_light/landing_inbd_L_sw': FeatureType.Int,
      'B742/ext_light/landing_inbd_R_sw': FeatureType.Int,
      'B742/ext_light/landing_outbd_L_sw': FeatureType.Int,
      'B742/ext_light/landing_outbd_R_sw': FeatureType.Int,
    },
    [AircraftFeature.LogoLights]: {
      'B742/ext_light/logo_sw': FeatureType.Int,
    },
    [AircraftFeature.NavigationLights]: false,
    [AircraftFeature.StrobeLights]: false,
    [AircraftFeature.TaxiLights]: {
      'B742/ext_light/runway_turnoff_L_sw': FeatureType.Int,
      'B742/ext_light/runway_turnoff_R_sw': FeatureType.Int,
    },
    [AircraftFeature.WingLights]: {
      'B742/ext_light/wing_sw': FeatureType.Int,
    },
  }
  flapNames = {
    0: 'UP',
    1: 'CONF 1',
    2: 'CONF 1+F',
    3: 'CONF 2',
    4: 'CONF 3',
    5: 'FULL',
  }
  match(title, icao, config_path) {
    return ['boeing', '747-200'].every((w) => title.includes(w))
  }
  beaconLights(value) {
    return null
  }
  landingLights(inbd_l, inbd_r, outb_l, outb_r) {
    return inbd_l == 1 && inbd_r == 1 && outb_l == 1 && outb_r == 1
  }
  logoLights(value) {
    return value == 1
  }
  navigationLights(value) {
    return null
  }
  strobeLights(value) {
    return null
  }
  taxiLights(turnoff_l, turnoff_r) {
    return turnoff_l == 1 && turnoff_r == 1
  }
  wingLights(value) {
    return value === 1
  }
}
