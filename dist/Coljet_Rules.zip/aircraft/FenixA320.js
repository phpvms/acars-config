import { AircraftConfigSimType, AircraftFeature, FeatureType } from '../defs'
import { AircraftConfig } from '../interface/aircraft'
export default class FenixA320 extends AircraftConfig {
  meta = {
    id: 'fenix_a320',
    name: 'Fenix Airbus A319/A320/A321',
    sim: AircraftConfigSimType.MsFs,
    enabled: true,
    priority: 2,
    author: 'B.Fatih KOZ <https://github.com/FatihKoz>',
  }
  features = {
    [AircraftFeature.BeaconLights]: {
      S_OH_EXT_LT_BEACON: FeatureType.Int,
    },
    [AircraftFeature.LandingLights]: {
      S_OH_EXT_LT_LANDING_L: FeatureType.Int,
      S_OH_EXT_LT_LANDING_R: FeatureType.Int,
    },
    [AircraftFeature.LogoLights]: {
      S_OH_EXT_LT_NAV_LOGO: FeatureType.Int,
    },
    [AircraftFeature.NavigationLights]: {
      S_OH_EXT_LT_NAV_LOGO: FeatureType.Int,
    },
    [AircraftFeature.StrobeLights]: {
      S_OH_EXT_LT_STROBE: FeatureType.Int,
    },
    [AircraftFeature.TaxiLights]: {
      S_OH_EXT_LT_NOSE: FeatureType.Int,
    },
    [AircraftFeature.WingLights]: {
      S_OH_EXT_LT_WING: FeatureType.Int,
    },
    [AircraftFeature.EmergencyLights]: {
      S_OH_INT_LT_EMER: FeatureType.Int,
    },
    [AircraftFeature.Seatbelts]: {
      S_OH_SIGNS: FeatureType.Int,
    },
    [AircraftFeature.Battery]: {
      S_OH_ELEC_BAT1: FeatureType.Int,
      S_OH_ELEC_BAT2: FeatureType.Int,
      I_OH_ELEC_EXT_PWR_L: FeatureType.Int,
    },
    [AircraftFeature.APU]: {
      S_OH_ELEC_APU_MASTER: FeatureType.Int,
      I_OH_ELEC_APU_START_U: FeatureType.Int,
    },
    [AircraftFeature.Packs]: {
      S_OH_PNEUMATIC_PACK_1: FeatureType.Int,
      I_OH_PNEUMATIC_PACK_1_U: FeatureType.Int,
      S_OH_PNEUMATIC_PACK_2: FeatureType.Int,
      I_OH_PNEUMATIC_PACK_2_U: FeatureType.Int,
    },
    [AircraftFeature.Doors]: {
      Any_Exit_open_L: FeatureType.Int,
      Any_Exit_open_R: FeatureType.Int,
    },
    [AircraftFeature.AntiIce]: {
      S_OH_PNEUMATIC_WING_ANTI_ICE: FeatureType.Int,
      S_OH_PNEUMATIC_ENG1_ANTI_ICE: FeatureType.Int,
      S_OH_PNEUMATIC_ENG2_ANTI_ICE: FeatureType.Int,
    },
  }
  flapNames = {
    0: 'UP',
    1: 'CONF 1',
    2: 'CONF 1+F',
    3: 'CONF 2',
    4: 'CONF 3',
    5: 'FULL',
  }
  match(title, icao, config_path) {
    if (!title.includes('fenix')) {
      return false
    }
    if (config_path.includes('FNX_320_CFM_SL')) {
      return true
    }
    return ['a319', 'a320', 'a321'].some(
      (w) => title.includes(w) || config_path.includes(w),
    )
  }
  beaconLights(value) {
    return value == 1
  }
  landingLights(left, right) {
    return left == 2 && right == 2
  }
  logoLights(value) {
    return value == 1 || value == 2
  }
  navigationLights(value) {
    return value == 1 || value === 2
  }
  strobeLights(value) {
    if (value === 1) {
      return null
    }
    return value === 2
  }
  taxiLights(value) {
    return value === 1 || value === 2
  }
  wingLights(value) {
    return value === 1
  }
  emergencyLights(value) {
    return value === 1 || value === 2
  }
  seatbelts(value) {
    return value === 1
  }
  battery(b1, b2, ext_pwr) {
    return (b1 === 1 && b2 === 1) || ext_pwr === 1
  }
  apu(master_switch, avail_status) {
    return master_switch === 1 && avail_status === 1
  }
  packs(left_switch, left_message, right_switch, right_message) {
    return (
      (left_switch === 1 && left_message === 0) ||
      (right_switch === 1 && right_message === 0)
    )
  }
  doors(exits_left, exits_right) {
    return exits_left === 0 && exits_right === 0
  }
  antiIce(wing, eng1, eng2) {
    return wing === 1 || (eng1 === 1 && eng2 === 1)
  }
}
