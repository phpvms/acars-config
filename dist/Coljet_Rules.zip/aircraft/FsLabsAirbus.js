import { AircraftConfigSimType, AircraftFeature } from '../defs'
import { AircraftConfig } from '../interface/aircraft'
export default class FsLabsAirbus extends AircraftConfig {
  meta = {
    id: 'fslabs_airbus',
    name: 'FsLabs Airbus',
    sim: AircraftConfigSimType.Fsuipc,
    enabled: true,
    priority: 2,
  }
  features = {
    [AircraftFeature.BeaconLights]: false,
    [AircraftFeature.LandingLights]: false,
    [AircraftFeature.LogoLights]: false,
    [AircraftFeature.NavigationLights]: false,
    [AircraftFeature.StrobeLights]: false,
    [AircraftFeature.TaxiLights]: false,
    [AircraftFeature.WingLights]: false,
  }
  flapNames = {
    0: 'UP',
    1: 'CONF 1',
    2: 'CONF CHG',
    3: 'CONF CHG',
    4: 'CONF CHG',
    5: 'CONF CHG',
    6: 'CONF 1+F',
    7: 'CONF 2',
    8: 'CONF 3',
    9: 'FULL',
  }
  match(title, icao, config_path) {
    return ['fslabs'].every((w) => title.includes(w))
  }
}
