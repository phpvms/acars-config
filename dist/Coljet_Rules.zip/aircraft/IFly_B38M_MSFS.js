import { AircraftConfigSimType, AircraftFeature, FeatureType } from '../defs'
import { AircraftConfig } from '../interface/aircraft'
import GetDefaultFlaps from './_default_flaps'
export default class IFlyB38M_MSFS extends AircraftConfig {
  meta = {
    id: 'ifly_b38M_msfs',
    name: 'iFLY B737-MAX8',
    author: 'B.Fatih KOZ <https://github.com/FatihKoz>',
    sim: AircraftConfigSimType.MsFs,
    priority: 2,
    enabled: true,
  }
  features = {
    [AircraftFeature.BeaconLights]: {
      VC_Beacon_Light_SW_VAL: FeatureType.Int,
    },
    [AircraftFeature.LandingLights]: {
      VC_Landing_Light_1_SW_VAL: FeatureType.Int,
      VC_Landing_Light_2_SW_VAL: FeatureType.Int,
    },
    [AircraftFeature.LogoLights]: {
      VC_Logo_Light_SW_VAL: FeatureType.Int,
    },
    [AircraftFeature.NavigationLights]: {
      VC_Position_Light_SW_VAL: FeatureType.Int,
    },
    [AircraftFeature.StrobeLights]: {
      VC_Position_Light_SW_VAL: FeatureType.Int,
    },
    [AircraftFeature.TaxiLights]: {
      VC_Taxi_Light_SW_VAL: FeatureType.Int,
    },
    [AircraftFeature.WingLights]: {
      VC_Wing_Light_SW_VAL: FeatureType.Int,
    },
  }
  match(title, icao, config_path) {
    this.flapNames = GetDefaultFlaps('', 'b38m', '')
    return ['ifly', '737-max8'].every((w) => title.includes(w))
  }
  beaconLights(value) {
    return value == 10
  }
  landingLights(v1, v2) {
    return v1 == 20 && v2 == 20
  }
  navigationLights(value) {
    return value == 0 || value == 20
  }
  strobeLights(value) {
    return value == 0
  }
  taxiLights(value) {
    return value == 10
  }
  wingLights(value) {
    return value == 10
  }
}
