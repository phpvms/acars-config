import { AircraftConfigSimType, AircraftFeature, FeatureType } from '../defs'
import { AircraftConfig } from '../interface/aircraft'
import GetDefaultFlaps from './_default_flaps'
export default class JarDesignA330 extends AircraftConfig {
  meta = {
    id: 'jardesign_a330',
    name: 'JARDesign A330',
    sim: AircraftConfigSimType.XPlane,
    enabled: true,
    priority: 2,
  }
  features = {
    [AircraftFeature.BeaconLights]: {
      'sim/custom/xap/extlight/beacon_sw': FeatureType.Int,
    },
    [AircraftFeature.LandingLights]: {
      'sim/custom/xap/extlight/land_sw': FeatureType.Int,
    },
    [AircraftFeature.NavigationLights]: {
      'sim/custom/xap/extlight/navlogo_sw': FeatureType.Int,
    },
    [AircraftFeature.StrobeLights]: {
      'sim/custom/xap/extlight/strobe_sw': FeatureType.Int,
    },
    [AircraftFeature.TaxiLights]: {
      'sim/custom/xap/extlight/nose_sw': FeatureType.Int,
    },
  }
  /**
   * Determine if this config map should be used for the given aircraft
   *
   * @param {string} title The title of the aircraft, lowercased
   * @param {string=} icao The ICAO of the aircraft. Might not be available
   * @param {string=} config_path Path to the aircraft config. Might not be there
   * @return {boolean}
   */
  match(title, icao, config_path) {
    this.flapNames = GetDefaultFlaps('', 'a330', '')
    return ['jardesign', 'a330'].every((w) => title.includes(w))
  }
  beaconLights(value) {
    return value == 1
  }
  landingLights(value) {
    return value == 1
  }
  navigationLights(value) {
    return value == 1 || value == 2
  }
  strobeLights(value) {
    return value == 2
  }
  taxiLights(value) {
    return value == 1 || value == 2
  }
}
