import { AircraftConfigSimType, AircraftFeature, FeatureType } from '../defs'
import { AircraftConfig } from '../interface/aircraft'
import GetDefaultFlaps from './_default_flaps'
export default class PMDG_737_FSUIPC extends AircraftConfig {
  meta = {
    id: 'pmdg_737_fsuipc',
    name: 'PMDG 737',
    sim: AircraftConfigSimType.Fsuipc,
    priority: 2,
    enabled: true,
  }
  features = {
    [AircraftFeature.BeaconLights]: {
      '0x6501': FeatureType.Byte,
    },
    [AircraftFeature.LandingLights]: {
      '0x64F6': FeatureType.Byte,
    },
    [AircraftFeature.LogoLights]: false,
    [AircraftFeature.NavigationLights]: {
      '0x6500': FeatureType.Byte,
    },
    [AircraftFeature.StrobeLights]: {
      '0x6500': FeatureType.Byte,
    },
    [AircraftFeature.TaxiLights]: {
      '0x64FA': FeatureType.Byte,
    },
    [AircraftFeature.WingLights]: false,
  }
  /**
   * Determine if this config map should be used for the given aircraft
   *
   * @param {string} title The title of the aircraft, lowercased
   * @param {string=} icao The ICAO of the aircraft. Might not be available
   * @param {string=} config_path Path to the aircraft config. Might not be there
   * @return {boolean}
   */
  match(title, icao, config_path) {
    this.flapNames = GetDefaultFlaps('', 'b737', '')
    return ['pmdg', '737'].every((w) => title.includes(w))
  }
  beaconLights(value) {
    return value == 1
  }
  landingLights(value) {
    return value == 1
  }
  navigationLights(value) {
    return value == 0 || value == 2
  }
  strobeLights(value) {
    return value == 2
  }
  taxiLights(value) {
    return value == 1
  }
}
