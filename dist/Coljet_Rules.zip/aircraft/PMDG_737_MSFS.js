import { AircraftConfigSimType, AircraftFeature, FeatureType } from '../defs'
import { AircraftConfig } from '../interface/aircraft'
import GetDefaultFlaps from './_default_flaps'
export default class PMDG_737_MSFS extends AircraftConfig {
  meta = {
    id: 'pmdg_737_msfs',
    name: 'PMDG 737',
    sim: AircraftConfigSimType.MsFs,
    priority: 2,
    enabled: true,
  }
  features = {
    [AircraftFeature.BeaconLights]: {
      switch_124_73X: FeatureType.Int,
    },
    [AircraftFeature.LandingLights]: {
      switch_113_73X: FeatureType.Int,
      switch_114_73X: FeatureType.Int,
    },
    [AircraftFeature.LogoLights]: {
      switch_122_73X: FeatureType.Int,
    },
    [AircraftFeature.NavigationLights]: {
      switch_123_73X: FeatureType.Int,
    },
    [AircraftFeature.StrobeLights]: {
      switch_123_73X: FeatureType.Int,
    },
    [AircraftFeature.TaxiLights]: {
      switch_117_73X: FeatureType.Int,
    },
    [AircraftFeature.WingLights]: {
      switch_125_73X: FeatureType.Int,
    },
  }
  /**
   * Determine if this config map should be used for the given aircraft
   *
   * @param {string} title The title of the aircraft, lowercased
   * @param {string=} icao The ICAO of the aircraft. Might not be available
   * @param {string=} config_path Path to the aircraft config. Might not be there
   * @return {boolean}
   */
  match(title, icao, config_path) {
    this.flapNames = GetDefaultFlaps('', 'b737', '')
    return ['pmdg', '737'].every(
      (w) => title.includes(w) || config_path.includes(w),
    )
  }
  beaconLights(value) {
    return value == 100
  }
  landingLights(v1, v2) {
    return v1 == 100 && v2 == 100
  }
  logoLights(value) {
    return value == 100
  }
  navigationLights(value) {
    return value == 0 || value == 100
  }
  strobeLights(value) {
    return value == 0
  }
  taxiLights(value) {
    return value == 100
  }
  wingLights(value) {
    return value == 100
  }
}
