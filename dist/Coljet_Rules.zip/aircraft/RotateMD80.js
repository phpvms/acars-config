import { AircraftConfigSimType, AircraftFeature, FeatureType } from '../defs'
import { AircraftConfig } from '../interface/aircraft'
import GetDefaultFlaps from './_default_flaps'
export default class RotateMD80 extends AircraftConfig {
  meta = {
    id: 'rotate_md80',
    name: 'Rotate MD-80',
    sim: AircraftConfigSimType.XPlane,
    enabled: true,
    priority: 2,
  }
  features = {
    [AircraftFeature.BeaconLights]: {
      'Rotate/md80/lights/anticollision_light_switch': FeatureType.Int,
    },
    [AircraftFeature.LandingLights]: {
      'Rotate/md80/lights/wing_ldg_light_switch_r': FeatureType.Int,
      'Rotate/md80/lights/wing_ldg_light_switch_l': FeatureType.Int,
    },
    [AircraftFeature.LogoLights]: {
      'Rotate/md80/lights/logo_light_switch': FeatureType.Int,
    },
    [AircraftFeature.NavigationLights]: {
      'Rotate/md80/lights/pos_strobe_light_switch': FeatureType.Int,
    },
    [AircraftFeature.StrobeLights]: {
      'Rotate/md80/lights/pos_strobe_light_switch': FeatureType.Int,
    },
    [AircraftFeature.TaxiLights]: {
      'Rotate/md80/lights/nose_light_switch': FeatureType.Int,
    },
    [AircraftFeature.WingLights]: {
      'Rotate/md80/lights/wing_light_switch': FeatureType.Int,
    },
  }
  /**
   * Determine if this config map should be used for the given aircraft
   *
   * @param {string} title The title of the aircraft, lowercased
   * @param {string=} icao The ICAO of the aircraft. Might not be available
   * @param {string=} config_path Path to the aircraft config. Might not be there
   * @return {boolean}
   */
  match(title, icao, config_path) {
    this.flapNames = GetDefaultFlaps('', 'md80', '')
    return ['rotate', 'md-80'].every((w) => title.includes(w))
  }
  beaconLights(value) {
    return value == 1
  }
  landingLights(v1, v2) {
    return v1 == 2 && v2 == 2
  }
  logoLights(value) {
    return value == 1
  }
  navigationLights(value) {
    return value === 1 || value === 2
  }
  strobeLights(value) {
    return value === 2
  }
  taxiLights(value) {
    return value === 1 || value === 2
  }
  wingLights(value) {
    return value === 1
  }
}
