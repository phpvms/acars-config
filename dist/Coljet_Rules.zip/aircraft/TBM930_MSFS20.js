import { AircraftConfigSimType, AircraftFeature, FeatureType } from '../defs'
import { AircraftConfig } from '../interface/aircraft'
export default class TBM930_MSFS20 extends AircraftConfig {
  meta = {
    id: 'tbm_930_2020',
    name: 'TBM 930 2020',
    sim: AircraftConfigSimType.MsFs20,
    enabled: true,
    priority: 2,
  }
  features = {
    [AircraftFeature.BeaconLights]: {
      'A:LIGHT LOGO,bool': FeatureType.Int,
    },
    [AircraftFeature.LogoLights]: false,
  }
  flapNames = {
    0: 'UP',
    1: 'TO',
    2: 'LDG',
  }
  match(title, icao, config_path) {
    return title.includes('tbm') && title.includes('930')
  }
  beaconLights(value) {
    return value == 1
  }
}
