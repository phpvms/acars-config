import { AircraftConfigSimType, AircraftFeature, FeatureType } from '../defs'
import { AircraftConfig } from '../interface/aircraft'
export default class TBM930_MSFS24 extends AircraftConfig {
  meta = {
    id: 'tbm_930_2024',
    name: 'TBM 930 2024',
    sim: AircraftConfigSimType.MsFs24,
    enabled: true,
    priority: 2,
  }
  features = {
    [AircraftFeature.BeaconLights]: false,
    [AircraftFeature.TaxiLights]: {
      'A:LIGHT TAXI,bool': FeatureType.Int,
    },
    [AircraftFeature.LandingLights]: {
      'A:LIGHT LANDING,bool': FeatureType.Int,
    },
    [AircraftFeature.LogoLights]: false,
  }
  flapNames = {
    0: 'UP',
    1: 'TO',
    2: 'LDG',
  }
  match(title, icao, config_path) {
    return title.includes('tbm') && title.includes('930')
  }
  beaconLights(value) {
    return value == 1
  }
  landingLights(value) {
    return value == 1
  }
  taxiLights(value) {
    return value == 1
  }
}
