import { AircraftConfigSimType, AircraftFeature, FeatureType } from '../defs'
import { AircraftConfig } from '../interface/aircraft'
export default class Toliss extends AircraftConfig {
  meta = {
    id: 'toliss_airbus',
    name: 'ToLiss Airbus',
    sim: AircraftConfigSimType.XPlane,
    enabled: true,
    priority: 2,
    author: 'B.Fatih KOZ <https://github.com/FatihKoz>',
  }
  features = {
    [AircraftFeature.BeaconLights]: {
      'AirbusFBW/OHPLightSwitches': FeatureType.IntArray,
    },
    [AircraftFeature.LandingLights]: {
      'AirbusFBW/OHPLightSwitches': FeatureType.IntArray,
    },
    [AircraftFeature.LogoLights]: {
      'AirbusFBW/OHPLightSwitches': FeatureType.IntArray,
    },
    [AircraftFeature.NavigationLights]: {
      'AirbusFBW/OHPLightSwitches': FeatureType.IntArray,
    },
    [AircraftFeature.StrobeLights]: {
      'AirbusFBW/OHPLightSwitches': FeatureType.IntArray,
    },
    [AircraftFeature.TaxiLights]: {
      'AirbusFBW/OHPLightSwitches': FeatureType.IntArray,
    },
    [AircraftFeature.WingLights]: {
      'AirbusFBW/OHPLightSwitches': FeatureType.IntArray,
    },
    [AircraftFeature.EmergencyLights]: {
      'AirbusFBW/OHPLightSwitches': FeatureType.IntArray,
    },
    [AircraftFeature.Seatbelts]: {
      'AirbusFBW/OHPLightSwitches': FeatureType.IntArray,
    },
    [AircraftFeature.Battery]: {
      'AirbusFBW/BatOHPArray': FeatureType.IntArray,
    },
    [AircraftFeature.APU]: {
      'AirbusFBW/APUAvail': FeatureType.Int,
    },
    [AircraftFeature.Packs]: {
      'AirbusFBW/Pack1Flow': FeatureType.Int,
      'AirbusFBW/Pack2Flow': FeatureType.Int,
    },
    [AircraftFeature.Doors]: {
      'AirbusFBW/PaxDoorArray': FeatureType.IntArray,
    },
  }
  flapNames = {
    0: 'UP',
    1: 'CONF 1',
    2: 'CONF 2',
    3: 'CONF 3',
    4: 'FULL',
  }
  match(title, icao, config_path) {
    return ['high', 'fidelity', 'system'].every((w) => title.includes(w))
  }
  beaconLights(value) {
    return value[0] == 1
  }
  landingLights(value) {
    return value[4] == 2 && value[5] == 2
  }
  logoLights(value) {
    return value[2] == 1 || value[2] == 2
  }
  navigationLights(value) {
    return value[2] === 1 || value[2] === 2
  }
  wingLights(value) {
    return value[1] === 1
  }
  emergencyLights(value) {
    return value[10] === 1 || value[10] === 2
  }
  seatbelts(value) {
    return value[11] === 1
  }
  strobeLights(value) {
    // Ignore if the switch is on AUTO position
    if (value[7] === 1) {
      return null
    }
    return value[7] === 2
  }
  taxiLights(value) {
    return value[3] === 1 || value[3] === 2
  }
  battery(value) {
    return value[0] === 1 && value[1] === 1
  }
  APU(value) {
    return value === 1
  }
  packs(p1, p2) {
    return p1 > 0.5 || p2 > 0.5
  }
  doors(doors) {
    return !doors.includes(1)
  }
}
