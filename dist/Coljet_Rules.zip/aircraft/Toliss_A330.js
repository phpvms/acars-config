import { AircraftConfigSimType, AircraftFeature, FeatureType } from '../defs'
import { AircraftConfig } from '../interface/aircraft'
export default class Toliss_A330 extends AircraftConfig {
  meta = {
    id: 'toliss_a330',
    name: 'ToLiss Airbus A330',
    sim: AircraftConfigSimType.XPlane,
    enabled: true,
    priority: 2,
    author: 'B.Fatih KOZ <https://github.com/FatihKoz>',
  }
  features = {
    [AircraftFeature.BeaconLights]: {
      'AirbusFBW/OHPLightSwitches': FeatureType.IntArray,
    },
    [AircraftFeature.LandingLights]: {
      'AirbusFBW/OHPLightSwitches': FeatureType.IntArray,
    },
    [AircraftFeature.NavigationLights]: {
      'AirbusFBW/OHPLightSwitches': FeatureType.IntArray,
    },
    [AircraftFeature.StrobeLights]: {
      'AirbusFBW/OHPLightSwitches': FeatureType.IntArray,
    },
    [AircraftFeature.TaxiLights]: {
      'AirbusFBW/OHPLightSwitches': FeatureType.IntArray,
    },
    [AircraftFeature.APU]: {
      'AirbusFBW/APUAvail': FeatureType.Int,
    },
  }
  flapNames = {
    0: 'UP',
    1: 'CONF 1',
    2: 'CONF 2',
    3: 'CONF 3',
    4: 'FULL',
  }
  match(title, icao, config_path) {
    return ['a330-941'].every((w) => title.includes(w))
  }
  beaconLights(value) {
    return value[0] == 1
  }
  landingLights(value) {
    return value[4] == 1
  }
  navigationLights(value) {
    return value[2] == 1 || value[2] == 2
  }
  strobeLights(value) {
    // Ignore if the switch is on AUTO position
    if (value[7] == 1) {
      return null
    }
    return value[7] == 2
  }
  taxiLights(value) {
    return value[3] == 1 || value[3] == 2
  }
  APU(value) {
    return value == 1
  }
}
