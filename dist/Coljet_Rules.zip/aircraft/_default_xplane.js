import { AircraftConfigSimType, AircraftFeature, FeatureType } from '../defs'
import { AircraftConfig } from '../interface/aircraft'
import GetDefaultFlaps from './_default_flaps'
/**
 * The default configmap
 */
export default class DefaultXPlane extends AircraftConfig {
  meta = {
    id: 'xplane_default',
    name: 'xplane default',
    sim: AircraftConfigSimType.XPlane,
    enabled: true,
    priority: 1,
  }
  features = {
    [AircraftFeature.BeaconLights]: {
      'sim/cockpit2/switches/beacon_on': FeatureType.Int,
    },
    [AircraftFeature.LandingLights]: {
      'sim/cockpit2/switches/landing_lights_on': FeatureType.Int,
    },
    [AircraftFeature.NavigationLights]: {
      'sim/cockpit2/switches/navigation_lights_on': FeatureType.Int,
    },
    [AircraftFeature.StrobeLights]: {
      'sim/cockpit2/switches/strobe_lights_on': FeatureType.Int,
    },
    [AircraftFeature.TaxiLights]: {
      'sim/cockpit2/switches/taxi_light_on': FeatureType.Int,
    },
  }
  /**
   * See if the title, icao or config_path match with what the simulator
   * is saying. All of the values are passed in already lower-cased.
   * Return true or false
   *
   * The ICAO and config_path may not be available in some sims.
   *
   * @param {string} title The title of the aircraft
   * @param {string=} icao The ICAO of the aircraft. Might not be available
   * @param {string=} config_path Path to the aircraft config. Might not be there
   * @return {boolean}
   */
  match(title, icao, config_path) {
    this.flapNames = GetDefaultFlaps(title, icao, config_path)
    return true
  }
  /**
   * Parse the value that's returned by the sim
   * @param value
   * @return {boolean|null}
   */
  beaconLights(value) {
    return value == 1
  }
  /**
   * Parse the value that's returned by the sim
   * @param value
   * @return {boolean|null}
   */
  landingLights(value) {
    return value == 1
  }
  /**
   * Parse the value that's returned by the sim
   * @param value
   * @return {boolean|null}
   */
  navigationLights(value) {
    return value == 1
  }
  /**
   * Parse the value that's returned by the sim
   * @param value
   * @return {boolean|null}
   */
  strobeLights(value) {
    return value == 1
  }
  /**
   * Parse the value that's returned by the sim
   * @param value
   * @return {boolean|null}
   */
  taxiLights(value) {
    return value == 1
  }
}
