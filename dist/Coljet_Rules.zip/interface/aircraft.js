export class AircraftConfig {
  /**
   * Store all the flap names here
   */
  flapNames = {}
  /**
   *
   * @param args
   */
  apu(...args) {
    return null
  }
  /**
   *
   */
  autopilot(...args) {
    return null
  }
  /**
   * Provide an implementation for but, by default, it's null
   * @param args
   */
  beaconLights(...args) {
    return null
  }
  /**
   *
   * @param args
   */
  antiIce(...args) {
    return null
  }
  /**
   *
   * @param args
   */
  battery(...args) {
    return null
  }
  /**
   *
   * @param args
   */
  doors(...args) {
    return null
  }
  /**
   *
   * @param args
   */
  emergencyLights(...args) {
    return null
  }
  /**
   * Not Implemented
   */
  engines(...args) {
    return null
  }
  /**
   *
   */
  externalPower(...args) {
    return null
  }
  /**
   * Get the right text for the flaps. Default implementation
   *
   * @param {int} value
   * @returns {string}
   */
  flaps(value) {
    return this.flapNames[value] || value
  }
  /**
   * Not Implemented
   */
  landingGear(...args) {
    return null
  }
  /**
   *
   * @param args
   */
  landingLights(...args) {
    return null
  }
  /**
   *
   * @param args
   */
  logoLights(...args) {
    return null
  }
  /**
   *
   * @param args
   */
  navigationLights(...args) {
    return null
  }
  /**
   *
   */
  packs(...args) {
    return null
  }
  /**
   * Not Implemented
   */
  parkingBrakes(...args) {
    return null
  }
  seatbelts(...args) {
    return null
  }
  strobeLights(...args) {
    return null
  }
  taxiLights(...args) {
    return null
  }
  /**
   * Not Implemented
   *
   * @param args Variable arguments according to the
   */
  transponder(...args) {
    return null
  }
  /**
   *
   * @param args Variable arguments according to the
   */
  wingLights(...args) {
    return null
  }
}
