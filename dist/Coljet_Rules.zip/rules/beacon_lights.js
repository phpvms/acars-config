import { PirepState } from '../defs'
export default class BeaconLights {
  meta = {
    id: 'BEACON_LIGHTS',
    name: 'Beacon lights must be on when moving or engines running',
    enabled: true,
    message: 'Beacon lights must be on when moving or engines running',
    states: [
      PirepState.Pushback,
      PirepState.TaxiOut,
      PirepState.Takeoff,
      PirepState.InitialClimb,
      PirepState.Enroute,
      PirepState.Approach,
      PirepState.Final,
      PirepState.Landed,
      PirepState.TaxiIn,
    ],
    repeatable: false,
    cooldown: 60,
    max_count: 1,
    points: -5,
    delay_time: 5000,
  }
  violated(pirep, data, previousData) {
    const isMoving = data.groundSpeed.Knots > 2
    const enginesRunning = data.anyEnginesRunning
    // Violation if: engines running OR aircraft moving, but beacon lights are off
    // This applies at ALL times (on ground and in air)
    if (!enginesRunning && !isMoving) {
      return
    }
    return Acars.ViolatedAfterDelay(this.meta.id, this.meta.delay_time, () => {
      return !data.beaconLights
    })
  }
}
