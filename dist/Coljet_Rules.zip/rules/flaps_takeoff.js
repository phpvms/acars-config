import { PirepState } from '../defs'
export default class FlapsTakeoff {
  meta = {
    id: 'FLAPS_TAKEOFF',
    name: 'Flaps must be configured for takeoff',
    enabled: true,
    message: 'Flaps must be configured for takeoff',
    states: [PirepState.Takeoff],
    repeatable: false,
    cooldown: 60,
    max_count: 1,
    points: -10,
  }
  violated(pirep, data, previousData) {
    // Violation: flaps not configured (flaps position = 0) during takeoff
    return data.flaps === 0
  }
}
