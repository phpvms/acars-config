import { PirepState } from '../defs'
export default class LandingLightsOff10k {
  meta = {
    id: 'LANDING_LIGHTS_OFF_10K',
    name: 'Landing lights must be off above 10,000 feet AGL',
    enabled: true,
    message: 'Landing lights must be off above 10,000 feet AGL',
    states: [PirepState.InitialClimb, PirepState.Enroute],
    repeatable: false,
    cooldown: 60,
    max_count: 1,
    points: -5,
    delay_time: 30000,
  }
  violated(pirep, data, previousData) {
    const altitudeAGL = data.groundAltitude.Feet
    const isAbove10k = altitudeAGL > 10000
    // No violation if below 10,000 feet AGL
    if (!isAbove10k) {
      return
    }
    return Acars.ViolatedAfterDelay(this.meta.id, this.meta.delay_time, () => {
      // Violation: above 10k feet AGL but landing lights still on
      return data.landingLights
    })
  }
}
