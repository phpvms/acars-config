import { PirepState } from '../defs'
export default class LandingLightsOn {
  meta = {
    id: 'LANDING_LIGHTS_ON',
    name: 'Landing lights must be on during takeoff and landing',
    enabled: true,
    message: 'Landing lights must be on during takeoff and landing',
    states: [PirepState.Takeoff, PirepState.Landed],
    repeatable: true,
    cooldown: 300,
    max_count: 2,
    points: -5,
    delay_time: 5000,
  }
  violated(pirep, data, previousData) {
    return Acars.ViolatedAfterDelay(this.meta.id, this.meta.delay_time, () => {
      // Violation: landing lights are off during takeoff or landing
      return !data.landingLights
    })
  }
}
