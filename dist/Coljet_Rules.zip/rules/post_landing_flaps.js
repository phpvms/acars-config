import { PirepState } from '../defs'
export default class PostLandingFlaps {
  meta = {
    id: 'POST_LANDING_FLAPS',
    name: 'Flaps must be retracted after landing',
    enabled: true,
    message: 'Flaps must be retracted after landing',
    states: [PirepState.TaxiIn],
    repeatable: false,
    cooldown: 60,
    max_count: 1,
    points: -5,
    delay_time: 180000,
  }
  violated(pirep, data, previousData) {
    return Acars.ViolatedAfterDelay(this.meta.id, this.meta.delay_time, () => {
      // Violation: flaps not retracted (flaps position != 0)
      return data.flaps !== 0
    })
  }
}
