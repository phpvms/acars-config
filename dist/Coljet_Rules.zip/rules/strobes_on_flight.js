import { PirepState } from '../defs'
export default class StrobesOnFlight {
  meta = {
    id: 'STROBES_ON_FLIGHT',
    name: 'Strobes must be on during flight',
    enabled: true,
    message: 'Strobes must be on during flight',
    states: [
      PirepState.Takeoff,
      PirepState.InitialClimb,
      PirepState.Enroute,
      PirepState.Approach,
      PirepState.Final,
      PirepState.Landed,
    ],
    repeatable: false,
    cooldown: 60,
    max_count: 1,
    points: -5,
    delay_time: 5000,
  }
  violated(pirep, data, previousData) {
    return Acars.ViolatedAfterDelay(this.meta.id, this.meta.delay_time, () => {
      // Violation: strobes are off during flight
      return !data.strobeLights
    })
  }
}
