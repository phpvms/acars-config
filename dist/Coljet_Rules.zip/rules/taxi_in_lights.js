import { PirepState } from '../defs'
export default class TaxiInLights {
  meta = {
    id: 'TAXI_IN_LIGHTS',
    name: 'Taxi lights must be on during taxi in',
    enabled: true,
    message: 'Taxi lights must be on during taxi in',
    states: [PirepState.TaxiIn],
    repeatable: false,
    cooldown: 60,
    max_count: 1,
    points: -5,
    delay_time: 180000,
  }
  violated(pirep, data, previousData) {
    // Only check during taxi in on the ground
    if (!data.onGround) {
      return
    }
    // Only flag if actually moving and not parked
    const isMoving = data.groundSpeed.Knots >= 10
    const isParked = data.parkBrake && data.groundSpeed.Knots < 10
    const gearDown = !data.gearUp
    if (!isMoving || isParked || !gearDown) {
      return
    }
    return Acars.ViolatedAfterDelay(this.meta.id, this.meta.delay_time, () => {
      return !data.taxiLights
    })
  }
}
