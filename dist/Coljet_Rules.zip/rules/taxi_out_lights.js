import { PirepState } from '../defs'
export default class TaxiOut {
  meta = {
    id: 'TAXI_OUT_LIGHTS',
    name: 'Taxi out lights',
    enabled: true,
    message: 'Taxi out lights must be on',
    states: [PirepState.TaxiOut],
    repeatable: false,
    cooldown: 60,
    max_count: 1,
    points: -5,
    delay_time: 30000,
  }
  violated(pirep, data, previousData) {
    // Only check during taxi out on the ground
    if (!data.onGround) {
      return
    }
    // Only flag if actually moving and not parked
    const isMoving = data.groundSpeed.Knots >= 10
    const isPArked = data.parkBrake && data.groundSpeed.Knots < 10
    const gearDown = !data.gearUp
    if (!isMoving || isPArked || !gearDown) {
      return
    }
    return Acars.ViolatedAfterDelay(this.meta.id, this.meta.delay_time, () => {
      return !data.taxiLights
    })
  }
}
