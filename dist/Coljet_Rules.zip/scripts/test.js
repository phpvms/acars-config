/**
 *
 */
export default class ExampleScript {}
